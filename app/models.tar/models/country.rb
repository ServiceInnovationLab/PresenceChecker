# frozen_string_literal: true

class Country < ApplicationRecord
end
