# frozen_string_literal: true

class Movement < ApplicationRecord
  belongs_to :identity
end
